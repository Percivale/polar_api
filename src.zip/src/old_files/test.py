#%%
import numpy as np
a=[]
if a == []:
    print('ja')

print('You have not collected any data, press Y and <enter> to continue')
ans=input()
if ans == 'Y' or ans =='y':
    cont=True
else:
    cont=False
print(cont)
# %%
